<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>SM</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Responsive CSS -->
    <link href="css/responsive.css" rel="stylesheet">

    <link href="css/swiper.min.css" rel="stylesheet">

</head>

<body>
    <!-- Preloader Start -->
    <div id="preloader">
        <div class="colorlib-load"></div>
    </div>

    <!-- ***** Header Area Start ***** -->
    <header class="header_area animated">
        <div class="container-fluid">
            <div class="row align-items-center">
                <!-- Menu Area Start -->
                <div class="col-12 col-lg-10">
                    <div class="menu_area">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <!-- Logo -->
                            <a class="navbar-brand" href="#">SM</a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ca-navbar" aria-controls="ca-navbar" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                            <!-- Menu Area -->
                            <div class="collapse navbar-collapse" id="ca-navbar">
                                <ul class="navbar-nav ml-auto" id="nav">
                                    <li class="nav-item active"><a class="nav-link" href="#">ДОМОЙ</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#matracvegas">МАТРАСЫ ВЕГАС</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#matrackondor">МАТРАСЫ КОНДОР</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#ortovegas">ПОДУШКИ ВЕГАС</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#namatrasniki">НАМАТРАСНИКИ</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#ortoosnovaniya">ОСНОВАНИЯ ВЕГАС</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#contact">КОНТАКТЫ</a></li>
                                </ul>
                                <div class="sing-up-button d-lg-none">
                                    <a href="#">СВЯЗАТЬСЯ</a>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
                <!-- Signup btn -->
                <div class="col-12 col-lg-2">
                    <div class="sing-up-button d-none d-lg-block">
                        <a href="#">СКАЧАТЬ ПРАЙС</a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Wellcome Area Start ***** -->
    <section class="wellcome_area clearfix" id="home">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12 col-md">
                    <div class="wellcome-heading">
                        <h2>SMART CHOICE</h2>
                        <h3>SC</h3>
                        <div class="numbersMain">
	                        <h3>+375-29-366-07-72</h3>
	                        <h3>+375-29-566-07-72</h3>
                    	</div>
                    	<h5 style="color: #a7a7a7">Время работы: 08:00 - 21:00 (без выходных)</h5>
                        <p style="font-size: 24px;font-weight: 700;">Отличные матрасы по цене производителя</p>
                    </div>
                    <div class="get-start-area">
                        <!-- Form Start -->
                        <form action="#" method="post" class="form-inline">
                            <input type="email" class="form-control email" placeholder="Введите Ваш номер">
                            <input type="submit" class="submit" value="Заказать звонок">
                        </form>
                        <!-- Form End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Welcome thumb -->
        <div class="welcome-thumb wow fadeInDown" data-wow-delay="0.5s">
            <img src="img/bg-img/welcome-img.png" alt="">
        </div>
    </section>
    <!-- ***** Wellcome Area End ***** -->

    <!-- ***** Special Area Start ***** -->
    <section class="special-area bg-white section_padding_100" id="about">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Section Heading Area -->
                    <div class="section-heading text-center">
                        <h2>Наши преимущества</h2>
                        <div class="line-shape"></div>
                    </div>
                </div>
            </div>

            <div class="row">
                 <!-- Single Special Area -->
                <div class="col-12 col-md-4">
                    <div class="single-special text-center wow fadeInUp" data-wow-delay="0.6s">
                        <div class="single-icon">
                            <i class="ti-light-bulb" aria-hidden="true"></i>
                        </div>
                        <h4>Рассрочка на 12 месяцев без переплат</h4>
                        <p></p>
                    </div>
                </div>
                <!-- Single Special Area -->
                <div class="col-12 col-md-4">
                    <div class="single-special text-center wow fadeInUp" data-wow-delay="0.6s">
                        <div class="single-icon">
                            <i class="ti-thumb-up" aria-hidden="true"></i>
                        </div>
                        <h4>Мы принимаем карты рассрочки: <br>Халва, Карта Покупок, Черепаха</h4>
                        <p></p>
                    </div>
                </div>
                <!-- Single Special Area -->
                <div class="col-12 col-md-4">
                    <div class="single-special text-center wow fadeInUp" data-wow-delay="0.4s">
                        <div class="single-icon">
                            <i class="ti-car" aria-hidden="true"></i>
                        </div>
                        <h4>При заказе до 14:00 - привезем матрас уже сегодня!</h4>
                        <p></p>
                    </div>
                </div>
                <!-- Single Special Area -->
                <div class="col-12 col-md-4">
                    <div class="single-special text-center wow fadeInUp" data-wow-delay="0.2s">
                        <div class="single-icon">
                            <i class="ti-mobile" aria-hidden="true"></i>
                        </div>
                        <h4>Вывезем Ваш старый матрас</h4>
                        <p></p>
                    </div>
                </div>
                <!-- Single Special Area -->
                <div class="col-12 col-md-4">
                    <div class="single-special text-center wow fadeInUp" data-wow-delay="0.6s">
                        <div class="single-icon">
                            <i class="ti-gift" aria-hidden="true"></i>
                        </div>
                        <h4>Бесплатная доставка матраса до кровати</h4>
                        <p></p>
                    </div>
                </div>
                <!-- Single Special Area -->
                <div class="col-12 col-md-4">
                    <div class="single-special text-center wow fadeInUp" data-wow-delay="0.6s">
                        <div class="single-icon">
                            <i class="ti-pulse" aria-hidden="true"></i>
                        </div>
                        <h4>Без предоплаты + официальная гарантия</h4>
                        <p></p>
                    </div>
                </div>
            </div>
        </div>

		    <!-- ***** App Screenshots Area Start ***** -->
    <section class="app-screenshots-area bg-white section_padding_0_100 clearfix" id="screenshot">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <!-- Heading Text  -->
                    <div class="section-heading">
                        <h2>Наши акции</h2>
                        <div class="line-shape"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- App Screenshots Slides  -->
                    <div class="app_screenshots_slides owl-carousel">
                        <div class="single-shot">
                            <img src="img/scr-img/app-9.png" alt="">
                        </div>
                        <div class="single-shot">
                            <img src="img/scr-img/app-9.png" alt="">
                        </div>
                        <div class="single-shot">
                            <img src="img/scr-img/app-9.png" alt="">
                        </div>
                        <div class="single-shot">
                            <img src="img/scr-img/app-9.png" alt="">
                        </div>
                        <div class="single-shot">
                            <img src="img/scr-img/app-9.png" alt="">
                        </div>
                        <div class="single-shot">
                            <img src="img/scr-img/app-9.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** App Screenshots Area End *****====== -->

                    <!-- ***** App Screenshots Area Start ***** -->
    <section class="app-screenshots-area bg-white section_padding_0_100 clearfix" id="matracvegas">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <!-- Heading Text  -->
                    <div class="section-heading">
                        <h2>Матрасы "Вегас" (VEGAS)</h2>
                        <div class="line-shape"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="client-description text-center">
                        <p>“ ООО «Вегас» – первый в Беларуси производитель ортопедических матрасов. Компания была основана в 1997 году в свободной экономической зоне «Брест». Предприятие изначально делало ставку на производство матрасов под собственной маркой Vegas из высококачественного сырья и комплектующих от ведущих западных поставщиков.
Компания «Вегас» на протяжении многих лет предлагает своим покупателям продукт, в котором воплотились самые яркие мечты об исключительном отдыхе. Внимание к традициям и ультрасовременные технологии позволяют компании производить матрасы высочайшего качества. Обладая великолепными ортопедическими свойствами, они дарят вам глубокий, спокойный сон и быстро восстанавливают силы.
Основная цель компании с момента появления на рынке — забота о клиенте через предложение ему продукта максимально высокого качества.
 ”
                        </p>
                    </div>
                    <!-- App Screenshots Slides  -->
                    <div class="condor-category">
                        <ul class="nav nav-pills mb-3 mx-auto" id="pills-tab" role="tablist">
                          <li class="nav-item">
                            <a class="nav-link active" id="pills-pruzi-tab" data-toggle="pill" href="#pills-pruzi" role="tab" aria-controls="pills-pruzi" aria-selected="true">Зависимые пружины</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-latex-tab" data-toggle="pill" href="#pills-latex" role="tab" aria-controls="pills-latex" aria-selected="false">Независимые пружины</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-bez-tab" data-toggle="pill" href="#pills-bez" role="tab" aria-controls="pills-bez" aria-selected="false">Беспружинные матрасы</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-zest-tab" data-toggle="pill" href="#pills-zest" role="tab" aria-controls="pills-zest" aria-selected="false">Жесткие матрасы</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-light-tab" data-toggle="pill" href="#pills-light" role="tab" aria-controls="pills-light" aria-selected="false">Мягкие матрасы</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-hard-tab" data-toggle="pill" href="#pills-hard" role="tab" aria-controls="pills-hard" aria-selected="false">С повышенной нагрузкой</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-sale-tab" data-toggle="pill" href="#pills-sale" role="tab" aria-controls="pills-sale" aria-selected="false">Недорогие матрасы</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-child-tab" data-toggle="pill" href="#pills-child" role="tab" aria-controls="pills-child" aria-selected="false">Детские матрасы</a>
                          </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContent">
                          <div class="tab-pane fade show active" id="pills-pruzi" role="tabpanel" aria-labelledby="pills-pruzi-tab">
                              <div class="swiper-container">
                                <div class="swiper-wrapper">
                                  <div class="swiper-slide">
                                    <div class="row" style="padding: 20px;">
                                        <div class="col-lg-6">
                                            <div class="special_description_img">
                                                <img src="images/matras/dt-mattress-smart-pulse.jpg" alt="">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xl-5 ml-xl-auto">
                                            <div class="special_description_content">
                                                <h2>Матрас Хит 1</h2>
                                                <div class="smallMatrasInfo">Самая доступная модель Vegas для тех, кто ищет оптимальное соотношение цены и качества.</div>
                                                    <div class="matrasInfo">
                                                    <p><b>Тип матраса</b> - независимые пружины</p>
                                                    <p><b>Для возраста</b> - взрослым</p>
                                                    <p><b>Гарантийный срок (мес.)</b> - 18</p>
                                                    <p><b>Высота (см)</b> - 18</p>
                                                    <p><b>Уровень жесткости стороны 1</b> - среднемягкий</p>
                                                    <p><b>Уровень жесткости стороны 2</b> - средний</p>
                                                    <p><b>Коллекция</b> - Vegas ит</p>
                                                    <p><b>Срок службы (лет)</b> - 7</p>
                                                    <p><b>Максимальная нагрузка на 1 спальное место (кг)</b> - 100</p>
                                                    <p><b>Пружинный блок</b> - TFK</p>
                                                    <p><b>Количество пружин (на м2)</b> - 256</p>
                                                    <p><b>Съемный чехол</b> - да</p>
                                                        <div class="app-download-area">
                                                            <div class="app-download-btn wow fadeInUp" data-wow-delay="0.2s">
                                                                <div class="pprice">351 руб</div>
                                                                <!-- Google Store Btn -->
                                                                <a href="#">
                                                                    <i class="fa fa-money"></i>
                                                                    <p class="mb-0"><span></span>Купить</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                            </div>
                                  </div>
                                  <div class="swiper-slide">Slide 2</div>
                                  <div class="swiper-slide">Slide 3</div>
                                </div>
                                <!-- Add Pagination -->
                                <div class="swiper-pagination"></div>
                                <!-- Add Arrows -->
                                <div class="swiper-button-next"></div>
                                <div class="swiper-button-prev"></div>
                              </div>
                        </div>
                          <div class="tab-pane fade" id="pills-latex" role="tabpanel" aria-labelledby="pills-latex-tab">....</div>
                          <div class="tab-pane fade" id="pills-bez" role="tabpanel" aria-labelledby="pills-bez-tab">....</div>
                          <div class="tab-pane fade" id="pills-zest" role="tabpanel" aria-labelledby="pills-zest-tab">...</div>
                          <div class="tab-pane fade" id="pills-light" role="tabpanel" aria-labelledby="pills-light-tab">...</div>
                          <div class="tab-pane fade" id="pills-hard" role="tabpanel" aria-labelledby="pills-hard-tab">...</div>
                          <div class="tab-pane fade" id="pills-sale" role="tabpanel" aria-labelledby="pills-sale-tab">...1</div>
                          <div class="tab-pane fade" id="pills-child" role="tabpanel" aria-labelledby="pills-child-tab">...1</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** App Screenshots Area End *****====== -->

    		    <!-- ***** App Screenshots Area Start ***** -->
    <section class="app-screenshots-area bg-white section_padding_0_100 clearfix" id="matrackondor">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <!-- Heading Text  -->
                    <div class="section-heading">
                        <h2>Матрасы "Кондор" (KONDOR)</h2>
                        <div class="line-shape"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                	<div class="client-description text-center">
                        <p>“ Компания «Кондор» производит матрасы с 2003 года. Лучшие материалы, лучшее качество, лучшие цены – основной девиз компании. Главное отличие матрасов «Кондор» - применение современного клея-расплава для соединения 	
							Также компания «Кондор» отказалась от использования в матрасах пенополиуретана (ППУ) полностью заменив его природным материалом – натуральным латексом.
							Уникальной особенностью двуспальных матрасов «Кондор» является возможность комплектации пружинным блоком «Tango», что позволяет создать разную жесткость для каждого спального места и добиться максимально комфортного сна при большой разнице в весе у партнеров. ”
                        </p>
                    </div>
                    <!-- App Screenshots Slides  -->
                    <div class="condor-category">
                        <ul class="nav nav-pills mb-3 mx-auto" id="pills-tab" role="tablist">
						  <li class="nav-item">
						    <a class="nav-link active" id="pills-pruzi-tab" data-toggle="pill" href="#pills-pruzi" role="tab" aria-controls="pills-pruzi" aria-selected="true">Пружинные матрасы</a>
						  </li>
						  <li class="nav-item">
						    <a class="nav-link" id="pills-latex-tab" data-toggle="pill" href="#pills-latex" role="tab" aria-controls="pills-latex" aria-selected="false">Латексные матрасы</a>
						  </li>
						  <li class="nav-item">
						    <a class="nav-link" id="pills-zest-tab" data-toggle="pill" href="#pills-zest" role="tab" aria-controls="pills-zest" aria-selected="false">Жесткие матрасы</a>
						  </li>
						  <li class="nav-item">
						    <a class="nav-link" id="pills-light-tab" data-toggle="pill" href="#pills-light" role="tab" aria-controls="pills-light" aria-selected="false">Мягкие матрасы</a>
						  </li>
						  <li class="nav-item">
						    <a class="nav-link" id="pills-hard-tab" data-toggle="pill" href="#pills-hard" role="tab" aria-controls="pills-hard" aria-selected="false">С повышенной нагрузкой</a>
						  </li>
						  <li class="nav-item">
						    <a class="nav-link" id="pills-sale-tab" data-toggle="pill" href="#pills-sale" role="tab" aria-controls="pills-sale" aria-selected="false">Недорогие матрасы</a>
						  </li>
						</ul>
						<div class="tab-content" id="pills-tabContent">
						  <div class="tab-pane fade show active" id="pills-pruzi" role="tabpanel" aria-labelledby="pills-pruzi-tab">
						  	  <div class="swiper-container">
							    <div class="swiper-wrapper">
							      <div class="swiper-slide">
							      	<div class="row" style="padding: 20px;">
					                    <div class="col-lg-6">
					                        <div class="special_description_img">
					                            <img src="images/matras/dt-mattress-smart-pulse.jpg" alt="">
					                        </div>
					                    </div>
					                    <div class="col-lg-6 col-xl-5 ml-xl-auto">
					                        <div class="special_description_content">
					                            <h2>Матрас Хит 1</h2>
					                            <div class="smallMatrasInfo">Самая доступная модель Vegas для тех, кто ищет оптимальное соотношение цены и качества.</div>
						                            <div class="matrasInfo">
						                            <p><b>Тип матраса</b> - независимые пружины</p>
						                            <p><b>Для возраста</b> - взрослым</p>
						                            <p><b>Гарантийный срок (мес.)</b> - 18</p>
						                            <p><b>Высота (см)</b> - 18</p>
						                            <p><b>Уровень жесткости стороны 1</b> - среднемягкий</p>
						                            <p><b>Уровень жесткости стороны 2</b> - средний</p>
						                            <p><b>Коллекция</b> - Vegas ит</p>
						                            <p><b>Срок службы (лет)</b> - 7</p>
						                            <p><b>Максимальная нагрузка на 1 спальное место (кг)</b> - 100</p>
						                            <p><b>Пружинный блок</b> - TFK</p>
						                            <p><b>Количество пружин (на м2)</b> - 256</p>
													<p><b>Съемный чехол</b> - да</p>
							                            <div class="app-download-area">
							                                <div class="app-download-btn wow fadeInUp" data-wow-delay="0.2s">
							                                	<div class="pprice">351 руб</div>
							                                    <!-- Google Store Btn -->
							                                    <a href="#">
							                                        <i class="fa fa-money"></i>
							                                        <p class="mb-0"><span></span>Купить</p>
							                                    </a>
							                                </div>
							                            </div>
						                        	</div>
					                    	</div>
		                				</div>
						  	</div>
							      </div>
							      <div class="swiper-slide">Slide 2</div>
							      <div class="swiper-slide">Slide 3</div>
							    </div>
							    <!-- Add Pagination -->
							    <div class="swiper-pagination"></div>
							    <!-- Add Arrows -->
							    <div class="swiper-button-next"></div>
							    <div class="swiper-button-prev"></div>
							  </div>
						</div>
						  <div class="tab-pane fade" id="pills-latex" role="tabpanel" aria-labelledby="pills-latex-tab">....</div>
						  <div class="tab-pane fade" id="pills-zest" role="tabpanel" aria-labelledby="pills-zest-tab">...</div>
						  <div class="tab-pane fade" id="pills-light" role="tabpanel" aria-labelledby="pills-light-tab">...</div>
						  <div class="tab-pane fade" id="pills-hard" role="tabpanel" aria-labelledby="pills-hard-tab">...</div>
						  <div class="tab-pane fade" id="pills-sale" role="tabpanel" aria-labelledby="pills-sale-tab">...1</div>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** App Screenshots Area End *****====== -->

                    <!-- ***** App Screenshots Area Start ***** -->
    <section class="app-screenshots-area bg-white section_padding_0_100 clearfix" id="ortovegas">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <!-- Heading Text  -->
                    <div class="section-heading">
                        <h2>Ортопедические подушки "Вегас"</h2>
                        <div class="line-shape"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="client-description text-center">
                        <p>“ От правильно подобранной подушки зависит не только крепкий cон и хорошее настроение, но и наше здоровье. Для комфортного здорового отдыха нашей голове требуется дополнительная поддержка. Шея во время сна должна располагаться в естественном положении, позвоночник должен быть ровным, мышцы расслаблены. Обычная подушка не может обеспечить такую поддержку. Именно поэтому необходимо использовать ортопедическую подушку. ”
                        </p>
                    </div>
                    <!-- App Screenshots Slides  -->
                    <div class="condor-category">
                        <ul class="nav nav-pills mb-3 mx-auto" id="pills-tab" role="tablist">
                          <li class="nav-item">
                            <a class="nav-link active" id="pills-pruzi-tab" data-toggle="pill" href="#pills-pruzi" role="tab" aria-controls="pills-pruzi" aria-selected="true">Детские подушки</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-latex-tab" data-toggle="pill" href="#pills-latex" role="tab" aria-controls="pills-latex" aria-selected="false">Подушки для мам</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-zest-tab" data-toggle="pill" href="#pills-zest" role="tab" aria-controls="pills-zest" aria-selected="false">Подушки из MemoryFoam</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-light-tab" data-toggle="pill" href="#pills-light" role="tab" aria-controls="pills-light" aria-selected="false">Подушки из латекса</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-hard-tab" data-toggle="pill" href="#pills-hard" role="tab" aria-controls="pills-hard" aria-selected="false">Гелевые подушки</a>
                          </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContent">
                          <div class="tab-pane fade show active" id="pills-pruzi" role="tabpanel" aria-labelledby="pills-pruzi-tab">
                              <div class="swiper-container">
                                <div class="swiper-wrapper">
                                  <div class="swiper-slide">
                                    <div class="row" style="padding: 20px;">
                                        <div class="col-lg-6">
                                            <div class="special_description_img">
                                                <img src="images/matras/dt-mattress-smart-pulse.jpg" alt="">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xl-5 ml-xl-auto">
                                            <div class="special_description_content">
                                                <h2>Матрас Хит 1</h2>
                                                <div class="smallMatrasInfo">Самая доступная модель Vegas для тех, кто ищет оптимальное соотношение цены и качества.</div>
                                                    <div class="matrasInfo">
                                                    <p><b>Тип матраса</b> - независимые пружины</p>
                                                    <p><b>Для возраста</b> - взрослым</p>
                                                    <p><b>Гарантийный срок (мес.)</b> - 18</p>
                                                    <p><b>Высота (см)</b> - 18</p>
                                                    <p><b>Уровень жесткости стороны 1</b> - среднемягкий</p>
                                                    <p><b>Уровень жесткости стороны 2</b> - средний</p>
                                                    <p><b>Коллекция</b> - Vegas ит</p>
                                                    <p><b>Срок службы (лет)</b> - 7</p>
                                                    <p><b>Максимальная нагрузка на 1 спальное место (кг)</b> - 100</p>
                                                    <p><b>Пружинный блок</b> - TFK</p>
                                                    <p><b>Количество пружин (на м2)</b> - 256</p>
                                                    <p><b>Съемный чехол</b> - да</p>
                                                        <div class="app-download-area">
                                                            <div class="app-download-btn wow fadeInUp" data-wow-delay="0.2s">
                                                                <div class="pprice">351 руб</div>
                                                                <!-- Google Store Btn -->
                                                                <a href="#">
                                                                    <i class="fa fa-money"></i>
                                                                    <p class="mb-0"><span></span>Купить</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                            </div>
                                  </div>
                                  <div class="swiper-slide">Slide 2</div>
                                  <div class="swiper-slide">Slide 3</div>
                                </div>
                                <!-- Add Pagination -->
                                <div class="swiper-pagination"></div>
                                <!-- Add Arrows -->
                                <div class="swiper-button-next"></div>
                                <div class="swiper-button-prev"></div>
                              </div>
                        </div>
                          <div class="tab-pane fade" id="pills-latex" role="tabpanel" aria-labelledby="pills-latex-tab">....</div>
                          <div class="tab-pane fade" id="pills-zest" role="tabpanel" aria-labelledby="pills-zest-tab">...</div>
                          <div class="tab-pane fade" id="pills-light" role="tabpanel" aria-labelledby="pills-light-tab">...</div>
                          <div class="tab-pane fade" id="pills-hard" role="tabpanel" aria-labelledby="pills-hard-tab">...</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** App Screenshots Area End *****====== -->

                        <!-- ***** App Screenshots Area Start ***** -->
    <section class="app-screenshots-area bg-white section_padding_0_100 clearfix" id="namatrasniki">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <!-- Heading Text  -->
                    <div class="section-heading">
                        <h2>Наматрасники</h2>
                        <div class="line-shape"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="client-description text-center">
                        <p>“ Наматрасник выполняет целый ряд функций. Основные из них являются: защита матраса от всех внешних негативных воздействий; сохраняет микроклимат, который идеально подходит для человеческого тела, то есть наматрасник создаёт теплоизоляционный слой, чтобы сохранить тепло на поверхности; помогает регулировать жёсткость матраса; помогает выровнять поверхность матраса с вмятинами. 
                        Это позволяет сохранить чистоту и целостность матраса, поскольку его стоимость не позволяет часто менять на новый. Негрубый наматрасник намного проще чистить, чем габаритный матрас, и стоимость их гораздо ниже. Поэтому наматрасник принимает весь удар загрязнений на себя, избавляя матрас от износа и пачканья. ”
                        </p>
                    </div>
                    <!-- App Screenshots Slides  -->
                    <div class="condor-category">
                        <ul class="nav nav-pills mb-3 mx-auto" id="pills-tab" role="tablist">
                          <li class="nav-item">
                            <a class="nav-link active" id="pills-pruzi-tab" data-toggle="pill" href="#pills-pruzi" role="tab" aria-controls="pills-pruzi" aria-selected="true">Защитные наматрасники Kondor</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-latex-tab" data-toggle="pill" href="#pills-latex" role="tab" aria-controls="pills-latex" aria-selected="false">одифицирующие наматрасники Kondor</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-zest-tab" data-toggle="pill" href="#pills-zest" role="tab" aria-controls="pills-zest" aria-selected="false">Защитные наматрасники Vegas</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-light-tab" data-toggle="pill" href="#pills-light" role="tab" aria-controls="pills-light" aria-selected="false">Модифицирующие наматрасники Vegas</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-hard-tab" data-toggle="pill" href="#pills-hard" role="tab" aria-controls="pills-hard" aria-selected="false">Детские наматрасники Vegas</a>
                          </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContent">
                          <div class="tab-pane fade show active" id="pills-pruzi" role="tabpanel" aria-labelledby="pills-pruzi-tab">
                              <div class="swiper-container">
                                <div class="swiper-wrapper">
                                  <div class="swiper-slide">
                                    <div class="row" style="padding: 20px;">
                                        <div class="col-lg-6">
                                            <div class="special_description_img">
                                                <img src="images/matras/dt-mattress-smart-pulse.jpg" alt="">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xl-5 ml-xl-auto">
                                            <div class="special_description_content">
                                                <h2>Матрас Хит 1</h2>
                                                <div class="smallMatrasInfo">Самая доступная модель Vegas для тех, кто ищет оптимальное соотношение цены и качества.</div>
                                                    <div class="matrasInfo">
                                                    <p><b>Тип матраса</b> - независимые пружины</p>
                                                    <p><b>Для возраста</b> - взрослым</p>
                                                    <p><b>Гарантийный срок (мес.)</b> - 18</p>
                                                    <p><b>Высота (см)</b> - 18</p>
                                                    <p><b>Уровень жесткости стороны 1</b> - среднемягкий</p>
                                                    <p><b>Уровень жесткости стороны 2</b> - средний</p>
                                                    <p><b>Коллекция</b> - Vegas ит</p>
                                                    <p><b>Срок службы (лет)</b> - 7</p>
                                                    <p><b>Максимальная нагрузка на 1 спальное место (кг)</b> - 100</p>
                                                    <p><b>Пружинный блок</b> - TFK</p>
                                                    <p><b>Количество пружин (на м2)</b> - 256</p>
                                                    <p><b>Съемный чехол</b> - да</p>
                                                        <div class="app-download-area">
                                                            <div class="app-download-btn wow fadeInUp" data-wow-delay="0.2s">
                                                                <div class="pprice">351 руб</div>
                                                                <!-- Google Store Btn -->
                                                                <a href="#">
                                                                    <i class="fa fa-money"></i>
                                                                    <p class="mb-0"><span></span>Купить</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                            </div>
                                  </div>
                                  <div class="swiper-slide">Slide 2</div>
                                  <div class="swiper-slide">Slide 3</div>
                                </div>
                                <!-- Add Pagination -->
                                <div class="swiper-pagination"></div>
                                <!-- Add Arrows -->
                                <div class="swiper-button-next"></div>
                                <div class="swiper-button-prev"></div>
                              </div>
                        </div>
                          <div class="tab-pane fade" id="pills-latex" role="tabpanel" aria-labelledby="pills-latex-tab">....</div>
                          <div class="tab-pane fade" id="pills-zest" role="tabpanel" aria-labelledby="pills-zest-tab">...</div>
                          <div class="tab-pane fade" id="pills-light" role="tabpanel" aria-labelledby="pills-light-tab">...</div>
                          <div class="tab-pane fade" id="pills-hard" role="tabpanel" aria-labelledby="pills-hard-tab">...</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** App Screenshots Area End *****====== -->

                            <!-- ***** App Screenshots Area Start ***** -->
    <section class="app-screenshots-area bg-white section_padding_0_100 clearfix" id="ortoosnovaniya">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <!-- Heading Text  -->
                    <div class="section-heading">
                        <h2>Ортопедические основания</h2>
                        <div class="line-shape"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="client-description text-center">
                        <p>“ Для того, чтобы пружинный блок или монолит работал наиболее эффективно, а ортопедический эффект вашего матраса проявлялся в полной мере, мы рекомендуем использовать специальные ортопедические основания. Гибкие деревянные ламели оснований обладают упругими свойствами и служат дополнительной амортизирующей основой, которая обеспечивает наиболее точную и мягкую подстройку матраса под ваше тело. ”
                        </p>
                    </div>
                    <!-- App Screenshots Slides  -->
                    <div class="condor-category">
                        <ul class="nav nav-pills mb-3 mx-auto" id="pills-tab" role="tablist">
                          <li class="nav-item">
                            <a class="nav-link active" id="pills-pruzi-tab" data-toggle="pill" href="#pills-pruzi" role="tab" aria-controls="pills-pruzi" aria-selected="true">Основания Vegas</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-latex-tab" data-toggle="pill" href="#pills-latex" role="tab" aria-controls="pills-latex" aria-selected="false">Подъемные механизмы Vegas</a>
                          </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContent">
                          <div class="tab-pane fade show active" id="pills-pruzi" role="tabpanel" aria-labelledby="pills-pruzi-tab">
                              <div class="swiper-container">
                                <div class="swiper-wrapper">
                                  <div class="swiper-slide">
                                    <div class="row" style="padding: 20px;">
                                        <div class="col-lg-6">
                                            <div class="special_description_img">
                                                <img src="images/matras/dt-mattress-smart-pulse.jpg" alt="">
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-xl-5 ml-xl-auto">
                                            <div class="special_description_content">
                                                <h2>Матрас Хит 1</h2>
                                                <div class="smallMatrasInfo">Самая доступная модель Vegas для тех, кто ищет оптимальное соотношение цены и качества.</div>
                                                    <div class="matrasInfo">
                                                    <p><b>Тип матраса</b> - независимые пружины</p>
                                                    <p><b>Для возраста</b> - взрослым</p>
                                                    <p><b>Гарантийный срок (мес.)</b> - 18</p>
                                                    <p><b>Высота (см)</b> - 18</p>
                                                    <p><b>Уровень жесткости стороны 1</b> - среднемягкий</p>
                                                    <p><b>Уровень жесткости стороны 2</b> - средний</p>
                                                    <p><b>Коллекция</b> - Vegas ит</p>
                                                    <p><b>Срок службы (лет)</b> - 7</p>
                                                    <p><b>Максимальная нагрузка на 1 спальное место (кг)</b> - 100</p>
                                                    <p><b>Пружинный блок</b> - TFK</p>
                                                    <p><b>Количество пружин (на м2)</b> - 256</p>
                                                    <p><b>Съемный чехол</b> - да</p>
                                                        <div class="app-download-area">
                                                            <div class="app-download-btn wow fadeInUp" data-wow-delay="0.2s">
                                                                <div class="pprice">351 руб</div>
                                                                <!-- Google Store Btn -->
                                                                <a href="#">
                                                                    <i class="fa fa-money"></i>
                                                                    <p class="mb-0"><span></span>Купить</p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                            </div>
                                  </div>
                                  <div class="swiper-slide">Slide 2</div>
                                  <div class="swiper-slide">Slide 3</div>
                                </div>
                                <!-- Add Pagination -->
                                <div class="swiper-pagination"></div>
                                <!-- Add Arrows -->
                                <div class="swiper-button-next"></div>
                                <div class="swiper-button-prev"></div>
                              </div>
                        </div>
                          <div class="tab-pane fade" id="pills-latex" role="tabpanel" aria-labelledby="pills-latex-tab">....</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** App Screenshots Area End *****====== -->

        <!-- Special Description Area -->
        
    </section>
    <!-- ***** Special Area End ***** -->

    <!-- ***** Awesome Features Start ***** -->
    <section class="awesome-feature-area bg-white section_padding_0_50 clearfix" id="features">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Heading Text -->
                    <div class="section-heading text-center">
                        <h2>Условия рассрочки</h2>
                        <div class="line-shape"></div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Single Feature Start -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-feature">
                        <i class="ti-user" aria-hidden="true"></i>
                        <h5>Условие 1</h5>
                        <p>Описания условия 1 Описания условия 1 Описания условия 1 Описания условия 1 </p>
                    </div>
                </div>
                <!-- Single Feature Start -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-feature">
                        <i class="ti-pulse" aria-hidden="true"></i>
                        <h5>Условие 2</h5>
                        <p>Описания условия 2 Описания условия 2 Описания условия 2 Описания условия 2 </p>
                    </div>
                </div>
                <!-- Single Feature Start -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-feature">
                        <i class="ti-dashboard" aria-hidden="true"></i>
                        <h5>Условие 3</h5>
                        <p>Описания условия 3 Описания условия 3 Описания условия 3 Описания условия 3 </p>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- ***** Awesome Features End ***** -->

        <!-- ***** Awesome Features Start ***** -->
    <section class="awesome-feature-area bg-white section_padding_0_50 clearfix" id="features">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Heading Text -->
                    <div class="section-heading text-center">
                        <h2>Способы оплаты</h2>
                        <div class="line-shape"></div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Single Feature Start -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-feature">
                        <i class="ti-user" aria-hidden="true"></i>
                        <h5>Способ 1</h5>
                        <p>Описания способа 1 Описания способа 1 Описания способа 1 Описания способа 1 </p>
                    </div>
                </div>
                <!-- Single Feature Start -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-feature">
                        <i class="ti-pulse" aria-hidden="true"></i>
                        <h5>Способ 2</h5>
                        <p>Описания способа 2 Описания способа 2 Описания способа 2 Описания способа 2 </p>
                    </div>
                </div>
                <!-- Single Feature Start -->
                <div class="col-12 col-sm-6 col-lg-4">
                    <div class="single-feature">
                        <i class="ti-dashboard" aria-hidden="true"></i>
                        <h5>Способ 3</h5>
                        <p>Описания способа 3 Описания способа 3 Описания способа 3 Описания способа 3 </p>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- ***** Awesome Features End ***** -->

    <!-- ***** Video Area Start ***** -->
    <div class="video-section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Video Area Start -->
                    <div class="video-area"">
                        <div class="video-play-btn">
                           <div class="section-heading text-center">
                        <h2>Сертификаты на продукцию</h2>
                        <div class="line-shape"></div>
                    </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Video Area End ***** -->

    <!-- ***** Cool Facts Area Start ***** -->
    <section class="cool_facts_area clearfix">
        <div class="container">
            <div class="row">
                <!-- Single Cool Fact-->
                <div class="col-12 col-md-3 col-lg-3">
                    <div class="single-cool-fact d-flex justify-content-center wow fadeInUp" data-wow-delay="0.2s">
                        <div class="counter-area">
                            <h3><span class="counter">90</span></h3>
                        </div>
                        <div class="cool-facts-content">
                            <i class="ion-arrow-down-a"></i>
                            <p>СДЕЛАНО <br> ПОКУПОК</p>
                        </div>
                    </div>
                </div>
                <!-- Single Cool Fact-->
                <div class="col-12 col-md-3 col-lg-3">
                    <div class="single-cool-fact d-flex justify-content-center wow fadeInUp" data-wow-delay="0.4s">
                        <div class="counter-area">
                            <h3><span class="counter">120</span></h3>
                        </div>
                        <div class="cool-facts-content">
                            <i class="ion-happy-outline"></i>
                            <p>СЧАСТЛИВЫХ <br> КЛИЕНТОВ</p>
                        </div>
                    </div>
                </div>
                <!-- Single Cool Fact-->
                <div class="col-12 col-md-3 col-lg-3">
                    <div class="single-cool-fact d-flex justify-content-center wow fadeInUp" data-wow-delay="0.6s">
                        <div class="counter-area">
                            <h3><span class="counter">40</span></h3>
                        </div>
                        <div class="cool-facts-content">
                            <i class="ion-person"></i>
                            <p>АКТИВНЫХ <br>ПОСТАВЩИКОВ</p>
                        </div>
                    </div>
                </div>
                <!-- Single Cool Fact-->
                <div class="col-12 col-md-3 col-lg-3">
                    <div class="single-cool-fact d-flex justify-content-center wow fadeInUp" data-wow-delay="0.8s">
                        <div class="counter-area">
                            <h3><span class="counter">4.8</span></h3>
                        </div>
                        <div class="cool-facts-content">
                            <i class="ion-ios-star-outline"></i>
                            <p>ОЦЕНКА <br> ПРОДУКЦИИ</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Cool Facts Area End ***** -->

    <!-- ***** Contact Us Area Start ***** -->
    <section class="footer-contact-area section_padding_100 clearfix" id="contact">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <!-- Heading Text  -->
                    <div class="section-heading">
                        <h2>Контакты</h2>
                        <div class="line-shape"></div>
                    </div>
                    <div class="footer-text">
                        <p>Контактная информация об организации</p>
                    </div>
                    <div class="address-text">
                        <p><span>Адрес:</span> г. Минск ул. Скорины 42/2</p>
                    </div>
                    <div class="phone-text">
                        <p><span>Телефон:</span> +375-11-123-123-1</p>
                    </div>
                    <div class="email-text">
                        <p><span>Email:</span> help@help.by</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <!-- Form Start-->
                    <div class="contact_from">
                        <form action="#" method="post">
                            <!-- Message Input Area Start -->
                            <div class="contact_input_area">
                                <div class="row">
                                    <!-- Single Input Area Start -->
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="name" id="name" placeholder="Ваше имя" required>
                                        </div>
                                    </div>
                                    <!-- Single Input Area Start -->
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <input type="email" class="form-control" name="email" id="email" placeholder="Вам E-mail" required>
                                        </div>
                                    </div>
                                    <!-- Single Input Area Start -->
                                    <div class="col-12">
                                        <div class="form-group">
                                            <textarea name="message" class="form-control" id="message" cols="30" rows="4" placeholder="Ваше сообщение *" required></textarea>
                                        </div>
                                    </div>
                                    <!-- Single Input Area Start -->
                                    <div class="col-12">
                                        <button type="submit" class="btn submit-btn">Отправить</button>
                                    </div>
                                </div>
                            </div>
                            <!-- Message Input Area End -->
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Contact Us Area End ***** -->

    <!-- ***** Footer Area Start ***** -->
    <footer class="footer-social-icon text-center section_padding_70 clearfix">
        <!-- footer logo -->
        <div class="footer-text">
            <h2>SM</h2>
        </div>
        <!-- social icon-->
        <div class="footer-social-icon">
            <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
            <a href="#"><i class="active fa fa-twitter" aria-hidden="true"></i></a>
            <a href="#"> <i class="fa fa-instagram" aria-hidden="true"></i></a>
            <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
        </div>
        <div class="footer-menu">
            <nav>
                <ul><!--
                    <li><a href="#">О</a></li>
                    <li><a href="#">Terms &amp; Conditions</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Contact</a></li>
                -->
                </ul>
            </nav>
        </div>
        <!-- Foooter Text-->
        <div class="copyright-text">
            <!-- ***** Removing this text is now allowed! This template is licensed under CC BY 3.0 ***** -->
            <p> ©2018 </p>
        </div>
    </footer>
    <!-- ***** Footer Area Start ***** -->

    <!-- Jquery-2.2.4 JS -->
    <script src="js/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap-4 Beta JS -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All Plugins JS -->
    <script src="js/plugins.js"></script>
    <!-- Slick Slider Js-->
    <script src="js/slick.min.js"></script>
    <!-- Footer Reveal JS -->
    <script src="js/footer-reveal.min.js"></script>
    <!-- Active JS -->
    <script src="js/active.js"></script>

    <script src="js/swiper.min.js"></script>

    <script>
    var swiper = new Swiper('.swiper-container', {
      pagination: {
        el: '.swiper-pagination',
        type: 'progressbar',
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
  </script>
</body>

</html>
