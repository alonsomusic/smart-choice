<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Smart-Choice</title>

    <link rel="icon" href="img/core-img/favicon.ico">

    <link href="css/style.css" rel="stylesheet">

    <link href="css/responsive.css" rel="stylesheet">

    <link href="css/swiper.min.css" rel="stylesheet">

</head>

<body>

    <div id="preloader">
        <div class="colorlib-load"></div>
    </div>

    <header class="header_area animated">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-12 col-lg-10">
                    <div class="menu_area">
                        <nav class="navbar navbar-expand-lg navbar-light">

                            <a class="navbar-brand" href="#">SM</a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ca-navbar" aria-controls="ca-navbar" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>

                            <div class="collapse navbar-collapse" id="ca-navbar">
                                <ul class="navbar-nav ml-auto" id="nav">
                                    <li class="nav-item active"><a class="nav-link" href="#">ГЛАВНАЯ</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#matracvegas">МАТРАСЫ ВЕГАС</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#matrackondor">МАТРАСЫ КОНДОР</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#ortovegas">ПОДУШКИ ВЕГАС</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#namatrasniki">НАМАТРАСНИКИ</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#ortoosnovaniya">ОСНОВАНИЯ ВЕГАС</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#contact">КОНТАКТЫ</a></li>
                                </ul>
                                <div class="sing-up-button d-lg-none">
                                    <a href="#">СВЯЗАТЬСЯ</a>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>

                <div class="col-12 col-lg-2">
                    <div class="sing-up-button d-none d-lg-block">
                        <a data-toggle="modal" data-target="#exampleModal" href="#">СКАЧАТЬ ИНСТРУКЦИЮ</a>
                    </div>
                </div>
            </div>
        </div>
    </header>
<body>
    <div id="app">
        <main>
            @yield('content')
        </main>
    </div>
<!-- Jquery-2.2.4 JS -->
    <script src="js/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap-4 Beta JS -->
    <script src="js/bootstrap.min.js"></script>
    <!-- All Plugins JS -->
    <script src="js/plugins.js"></script>
    <!-- Slick Slider Js-->
    <script src="js/slick.min.js"></script>
    <!-- Footer Reveal JS -->
    <script src="js/footer-reveal.min.js"></script>
    <!-- Active JS -->
    <script src="js/active.js"></script>

    <script src="js/swiper.min.js"></script>

    <script>
    var swiper = new Swiper('.swiper-container', {
      pagination: {
        el: '.swiper-pagination',
        type: 'progressbar',
      },
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
  </script>
</body>

</html>
