<?php

$to = $_POST['email']; 
$name = $_POST['name']; 
$phone = $_POST['phone']; 
$emailAdmin = "smart-choiceby@yandex.by";


$subject = "Инструкция по выбору матраса"; 

$message = ' 
<html> 
    <head> 
        <title>Инструкция по выбору матраса</title> 
    </head> 
    <body> 
    	<p>Имя: '.$name.'</p>
    	<p>Номер: '.$phone.'</p>
    	<p>Email: '.$to.'</p>
        <p><a href="http://smart-choice.by/matras.pdf>СКАЧАТЬ</a></p> 
    </body> 
</html>'; 

$headers  = "Content-type: text/html; charset=windows-1251 \r\n"; 
$headers .= "От кого: Smart-Choice <sm@smart-choice.by>\r\n"; 

mail($to, $subject, $message, $headers); 
mail($emailAdmin, $subject, $message, $headers); 

header('Location: ' . $_SERVER['HTTP_REFERER']);
?>