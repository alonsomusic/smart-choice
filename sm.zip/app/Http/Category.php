<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Category extends Model
{

    protected $fillable = ['name','alias','image','parent_id'];

    protected $guarded = [];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at', 'expiration'];

    public function product()
	{
            return $this->hasMany(Products::class);
	}

	public function subCategory()
	{
		return $this->hasMany('App\Category','parent_id','id');
	}
}